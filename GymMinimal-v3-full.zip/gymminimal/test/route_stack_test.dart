import 'package:flutter_test/flutter_test.dart';
import 'package:gymmane/services/local_store.dart';
import 'package:gymmane/state/fit_state.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    await Store.instance.init();
    fit.notes.clear();
    fit.goHome();
  });

  String exId() => fit.allExercises.first.id;

  test('going back from an exercise returns to where you came from', () {
    fit.goExercises();
    fit.openExercise(exId());
    expect(fit.handleBack(), isTrue);
    expect(fit.route, 'exercises');
  });

  test('a similar exercise opens on top and back returns to the first one', () {
    final a = fit.allExercises[0].id;
    final b = fit.allExercises[1].id;
    final c = fit.allExercises[2].id;
    fit.goExercises();
    fit.openExercise(a);
    fit.openExercise(b);
    fit.openExercise(c);
    expect(fit.activeExerciseId, c);
    fit.handleBack();
    expect((fit.route, fit.activeExerciseId), ('exercise-detail', b));
    fit.handleBack();
    expect((fit.route, fit.activeExerciseId), ('exercise-detail', a));
    fit.handleBack();
    expect(fit.route, 'exercises');
    fit.openExercise(c);
    fit.handleBack();
    expect(fit.route, 'exercises');
  });

  test('writing a note inside an exercise does not lock you in', () {
    fit.goExercises();
    fit.openExercise(exId());
    fit.openNoteEditor(exerciseId: exId());
    fit.closeNoteEditor();
    expect(fit.route, 'exercise-detail');
    fit.handleBack();
    expect(fit.route, 'exercises');
  });

  test('the journal of an exercise gives the exercise back', () {
    fit.goHome();
    fit.openExercise(exId());
    fit.goNotes(exerciseId: exId());
    fit.openNoteEditor(exerciseId: exId());
    fit.closeNoteEditor();
    expect(fit.route, 'notes');
    fit.backFromNotes();
    expect(fit.route, 'exercise-detail');
    fit.handleBack();
    expect(fit.route, 'home');
  });

  test('a routine opened from home goes back home', () {
    fit.goHome();
    fit.openRoutine(fit.createRoutine());
    fit.handleBack();
    expect(fit.route, 'home');
  });

  test('a routine opened from the routines list goes back to the list', () {
    fit.goHome();
    fit.goRoutines();
    final id = fit.createRoutine();
    fit.openRoutine(id);
    fit.openRoutine(fit.duplicateRoutine(id));
    fit.closeRoutineEdit();
    expect(fit.route, 'routines');
    fit.handleBack();
    expect(fit.route, 'home');
  });

  test('a route never comes back to itself', () {
    fit.goSettings();
    fit.goPlaces();
    fit.goPlaces();
    fit.backFromPlaces();
    expect(fit.route, 'settings');
  });

  test('the tabs at the bottom drop the stack', () {
    fit.goExercises();
    fit.openExercise(exId());
    fit.goProgress();
    expect(fit.handleBack(), isTrue);
    expect(fit.route, 'home');
  });

  test('an exercise opened from another exercise still leaves', () {
    fit.goExercises();
    fit.openExercise(exId());
    fit.openExercise(fit.allExercises[1].id);
    fit.handleBack();
    fit.handleBack();
    expect(fit.route, 'exercises');
  });

  test('every screen you can open knows how to come back', () {
    for (final open in <(String, void Function())>[
      ('preferences', fit.goPreferences),
      ('moments', fit.goMoments),
      ('awards', fit.goAwards),
    ]) {
      fit.goSettings();
      open.$2();
      expect(fit.route, open.$1);
      expect(fit.handleBack(), isTrue, reason: 'salir de ${open.$1} no puede cerrar la app');
      expect(fit.route, 'settings');
    }
  });

  test('back from home is the only one that leaves the app', () {
    fit.goHome();
    expect(fit.handleBack(), isFalse);
  });
}
